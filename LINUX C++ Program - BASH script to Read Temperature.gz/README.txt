Included are the sources for one class and two binaries that use this class.
To compile the programs, type 'make' to use the include Makefile.

The tempread.cpp and .h files include the CTempRead class, which is used to 
get temperature readings from the Temp@lert USB device. 

tempdemoloop.c is a program that reads the values from the USB device in a
loop and outputs them to the terminal with some extra text to make it more human 
readable. tempdemo will read and output a single temperature, which is useful 
for user made scripts. Both programs have command line parameters to alter the 
USB device read, and to change between Celsius and Fahrenheit output. Use the 
--help flag for more information.

example.sh is a simple bash script to read values from 'tempdemo' and append
them to a log file.
