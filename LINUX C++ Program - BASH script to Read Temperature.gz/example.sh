#!/bin/bash
# Example on how to use tempdemo in a script
# Get the temperature and append to log file with current date and time
# 
# Created by Stephen Beard 3/31/10
# Copyright (c) 2010 Temperature@lert

logfile=tempLog

echo "Temperature log file" > $logfile

while true 
do
    TEMPREAD=`tempdemo`
    DATE=`date`
    echo $DATE $TEMPREAD >> $logfile
    sleep 5
done
